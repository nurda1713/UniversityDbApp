namespace UniversityDbApp.Models;

public class Department
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;

    // Бір кафедрада бірнеше оқытушы болуы мүмкін.
    public ICollection<Teacher> Teachers { get; set; } = new List<Teacher>();
}
