namespace UniversityDbApp.Models;

public class Teacher
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;

    // Foreign Key және навигациялық қасиет.
    public int DepartmentId { get; set; }
    public Department? Department { get; set; }
}
