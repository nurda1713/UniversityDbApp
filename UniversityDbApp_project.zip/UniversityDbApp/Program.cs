using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using UniversityDbApp.Data;
using UniversityDbApp.Models;

var configuration = new ConfigurationBuilder()
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .Build();

var connectionString = configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string табылмады.");

var options = new DbContextOptionsBuilder<AppDbContext>()
    .UseSqlServer(connectionString)
    .Options;

using var db = new AppDbContext(options);

// Миграциялар арқылы құрылған кестелерге мысал деректерін қосу.
if (!db.Departments.Any())
{
    var department = new Department { Name = "Ақпараттық технологиялар" };
    department.Teachers.Add(new Teacher
    {
        FullName = "Айдос Нұрланұлы",
        Subject = "Бағдарламалау"
    });

    db.Departments.Add(department);
    db.SaveChanges();
}

Console.WriteLine("UniversityDb дерекқорындағы кафедралар мен оқытушылар:");
var departments = db.Departments
    .Include(d => d.Teachers)
    .ToList();

foreach (var department in departments)
{
    Console.WriteLine($"Кафедра: {department.Name}");
    foreach (var teacher in department.Teachers)
        Console.WriteLine($"  Оқытушы: {teacher.FullName}, пәні: {teacher.Subject}");
}
