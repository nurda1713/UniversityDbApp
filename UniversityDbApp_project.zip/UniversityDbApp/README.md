# UniversityDbApp — EF Core Code-First

## Жоба мақсаты
EF Core арқылы MS SQL Server дерекқорына қосылу, `Department` және `Teacher` модельдерін құру, олардың арасында One-to-Many (1-to-N) байланысын орнату және миграцияларды орындау.

## Қажетті орта
- Visual Studio 2022
- .NET 8 SDK
- SQL Server LocalDB (Visual Studio құрамында болуы мүмкін)

## Жобаны іске қосу
1. `UniversityDbApp.csproj` файлын Visual Studio арқылы ашыңыз.
2. NuGet пакеттерінің қалпына келуін күтіңіз (Restore).
3. `appsettings.json` ішіндегі `DefaultConnection` жолын өз SQL Server ортаңызға сәйкес тексеріңіз.
4. Visual Studio: **Tools → NuGet Package Manager → Package Manager Console** ашыңыз.
5. Консольде мына командаларды орындаңыз:

```powershell
Add-Migration InitialDb
Update-Database
```

6. Жобаны іске қосыңыз (F5 немесе Ctrl+F5). Консольде кафедра және оқытушы туралы мәлімет шығады.

## Модельдер байланысы
- Бір `Department` құрамында бірнеше `Teacher` болуы мүмкін.
- `Teacher.DepartmentId` — сыртқы кілт (Foreign Key).
- `Teacher.Department` — навигациялық қасиет.
- `Department.Teachers` — кафедраға тиесілі оқытушылар жиыны.

## Тапсыруға арналған дәлелдер
Өз компьютеріңізде миграция орындалғаннан кейін:
1. Package Manager Console терезесінде `Add-Migration InitialDb` және `Update-Database` нәтижесін скриншотқа түсіріңіз.
2. SQL Server Object Explorer ішінен `UniversityDb` дерекқорындағы `Departments` және `Teachers` кестелерін көрсететін скриншот жасаңыз.
3. Жобаның GitHub репозиторийіне осы файлдарды жүктеп, репозиторий сілтемесін Classroom тапсырмасына қосыңыз.

Ескерту: скриншоттар мен GitHub сілтемесін нақты компьютерде орындағаннан кейін өзіңіз қосуыңыз керек; бұл жоба файлдары оларды жалған түрде жасамайды.
